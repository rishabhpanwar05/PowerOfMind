package com.brahmakumari.powerofmind.adapter;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.brahmakumari.powerofmind.R;


/**
 * Created by rishabhpanwar on 09/04/17.
 */

public class MiniAudioAdapter extends RecyclerView.Adapter<MiniAudioAdapter.ViewInfoHolder> {

    String[] aud_titles;
    Context ctx;

    public MiniAudioAdapter(Context context, String[] aud_titles) {
        this.ctx = context;
        this.aud_titles=aud_titles;
    }
    @Override
    public ViewInfoHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_mini_audio, parent, false);
        final ViewInfoHolder result = new ViewInfoHolder(itemView);
        itemView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Log.d("Pos: ",""+result.getAdapterPosition());
            }
        });
        return new MiniAudioAdapter.ViewInfoHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewInfoHolder holder, int position) {
        holder.home_audio_tv.setText(aud_titles[position]);

        if(position%3==0)
            holder.constraintLayout.setBackgroundResource(R.color.miniAudioRed);
        else if(position%3==1)
            holder.constraintLayout.setBackgroundResource(R.color.miniAudioGreen);
        else
            holder.constraintLayout.setBackgroundResource(R.color.miniAudioGrey);
    }

    @Override
    public int getItemCount() {
        return aud_titles.length;
    }

    public class ViewInfoHolder extends RecyclerView.ViewHolder
    {
        protected TextView home_audio_tv;
        ConstraintLayout constraintLayout;

        public ViewInfoHolder(View itemView)
        {
            super(itemView);
            home_audio_tv = (TextView) itemView.findViewById(R.id.home_audio_tv);
            constraintLayout=(ConstraintLayout)itemView.findViewById(R.id.constraint_layout_mini_audio);
        }
    }
}

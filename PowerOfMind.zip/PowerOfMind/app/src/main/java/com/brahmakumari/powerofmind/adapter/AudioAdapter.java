package com.brahmakumari.powerofmind;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.brahmakumari.powerofmind.model.Audio;

import java.util.List;


/**
 * Created by rishabhpanwar on 09/04/17.
 */

public class AudioAdapter extends RecyclerView.Adapter<AudioAdapter.ViewInfoHolder>
{

    List<Audio> audios;
    Context ctx;

    public AudioAdapter(Context context, List<Audio> audios) {
        this.ctx = context;
        this.audios=audios;
    }
    @Override
    public ViewInfoHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_audio, parent, false);
        return new ViewInfoHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewInfoHolder holder, int position) {
        holder.audio_details.setText(audios.get(position).getAudio_title());
    }

    @Override
    public int getItemCount() {
        return audios.size();
    }

    public class ViewInfoHolder extends RecyclerView.ViewHolder
    {
        protected TextView audio_details;

        public ViewInfoHolder(View itemView)
        {
            super(itemView);
            audio_details = (TextView) itemView.findViewById(R.id.audio_details);
        }
    }

}

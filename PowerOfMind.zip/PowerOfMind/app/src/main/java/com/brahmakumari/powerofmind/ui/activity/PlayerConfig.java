package com.brahmakumari.powerofmind.ui.activity;

/**
 * Created by rishabhpanwar on 31/03/17.
 */

public class PlayerConfig {

    PlayerConfig(){

    }

    public static final String API_KEY="AIzaSyCR5kq0Y53GsZt_ByGSN79JX-H1VqAKauA";
}
